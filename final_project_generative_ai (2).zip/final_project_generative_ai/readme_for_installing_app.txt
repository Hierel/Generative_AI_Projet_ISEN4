dézipper le fichier
lancer powershell
s'assurer d'avoir installé python  3.13.7
se mettre dans le répertoire du projet dézippé sur powershell
taper la commande : pip install -r requirements.txt
ensuite taper : pip install ffmpeg-python
ensuite : python -m spacy download en_core_web_sm
ensuite télécharger sur ce site le zip "ffmpeg-8.0-essentials_build" : https://www.gyan.dev/ffmpeg/builds/?utm_source=chatgpt.com
	et configurer le chemin d'accès au fichier bin dans les variables d'environnement système